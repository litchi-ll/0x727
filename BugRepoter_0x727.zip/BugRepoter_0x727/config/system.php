<?php return [
'name'=>'0x727自动化编写报告平台',
'legitimate_ip'=>[],
'legitimate_type'=>'0',
'domain_key'=>'',
'socket_ip'=>'192.168.5.103',
'config_debug'=>'0',
'encryption_url'=>'1',
]; ?>