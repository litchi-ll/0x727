host = "192.168.5.102";
user = "";
password = "";
dbname = "";
port = 3306;